
'''
autores:
    Delia Hernandez Ruiz
    Jonathan Vasquez Mora
    Erick Hernandez Camacho
'''
from django.apps import AppConfig

class PagesConfig(AppConfig):
    name = 'pages'
