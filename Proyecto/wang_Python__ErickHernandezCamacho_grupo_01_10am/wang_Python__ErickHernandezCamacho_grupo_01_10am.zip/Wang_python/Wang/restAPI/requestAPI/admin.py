'''
autores:
    Delia Hernandez Ruiz
    Jonathan Vasquez Mora
    Erick Hernandez Camacho
'''


from django.contrib import admin
from .models import Pruebas

# Register your models here.

admin.site.register(Pruebas)